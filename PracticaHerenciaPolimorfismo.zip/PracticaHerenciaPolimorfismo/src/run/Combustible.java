package run;

public interface Combustible {
    void recargar();
}